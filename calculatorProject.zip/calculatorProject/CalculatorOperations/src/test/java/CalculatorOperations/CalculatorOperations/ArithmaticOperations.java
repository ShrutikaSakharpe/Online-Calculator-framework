package CalculatorOperations.CalculatorOperations;

import org.testng.annotations.Test;

import Repository.Repositorynumber;
import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;


public class ArithmaticOperations
{
	WebDriver wd;
	@Test (priority=0)
	public void multiplication() throws InterruptedException 
	{
		Repositorynumber.four(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.multiplication(wd).click();
		Repositorynumber.five(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.five(wd).click();
		Repositorynumber.equalto(wd).click();
		Repositorynumber.clear(wd).click();

	}
	@Test (priority=1)
	public void division() throws InterruptedException
	{
		Repositorynumber.four(wd).click();
		Repositorynumber.zero(wd).click();
		Repositorynumber.zero(wd).click();
		Repositorynumber.zero(wd).click();
		Repositorynumber.division(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.zero(wd).click();
		Repositorynumber.zero(wd).click();
		Repositorynumber.equalto(wd).click();
		Repositorynumber.clear(wd).click();
	}

	@Test (priority=2)
	public void addition() throws InterruptedException
	{
		Repositorynumber.minus(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.four(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.four(wd).click();
		Repositorynumber.addition(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.four(wd).click();
		Repositorynumber.five(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.four(wd).click();
		Repositorynumber.five(wd).click();
		Repositorynumber.equalto(wd).click();
		Repositorynumber.clear(wd).click();
	}
	
	@Test (priority=3)
	public void subtraction() throws InterruptedException
	{
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.four(wd).click();
		Repositorynumber.eight(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.minus(wd).click();
		Repositorynumber.minus(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.zero(wd).click();
		Repositorynumber.nine(wd).click();
		Repositorynumber.four(wd).click();
		Repositorynumber.eight(wd).click();
		Repositorynumber.two(wd).click();
		Repositorynumber.three(wd).click();
		Repositorynumber.equalto(wd).click();
		Repositorynumber.clear(wd).click();
	} 
	@BeforeTest
	public void beforeTest() 
	{

		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.calculator.net/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}
}
