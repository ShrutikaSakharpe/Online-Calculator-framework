package Repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Repositorynumber {

	public static WebElement addition (WebDriver wd)
	{
		WebElement add=wd.findElement(By.xpath("//tbody/tr[2]/td[2]/div[1]/div[1]/span[4]"));
		return add;
	}

	public static WebElement multiplication (WebDriver wd)
	{
		WebElement multiplication=wd.findElement(By.xpath("//span[contains(text(),'×')]"));
		return multiplication;
	}

	public static WebElement minus (WebDriver wd)
	{
		WebElement minus=wd.findElement(By.xpath("//span[contains(text(),'–')]"));
		return minus;
	}

	public static WebElement division (WebDriver wd)
	{
		WebElement div=wd.findElement(By.xpath("//tbody/tr[2]/td[2]/div[1]/div[4]/span[4]"));
		return div;
	}

	public static WebElement equalto (WebDriver wd)
	{
		WebElement equals=wd.findElement(By.xpath("//span[contains(text(),'=')]"));
		return equals;
	}
	
	public static WebElement clear (WebDriver wd)
	{
		WebElement clr=wd.findElement(By.xpath("//span[contains(text(),'AC')]"));
		return clr;
	}

	public static WebElement zero (WebDriver wd)
	{
		WebElement zero=wd.findElement(By.xpath("//tbody/tr[2]/td[2]/div[1]/div[4]/span[1]"));
		return zero;
	}

	public static WebElement one (WebDriver wd)
	{
		WebElement one=wd.findElement(By.xpath("//tbody/tr[2]/td[2]/div[1]/div[3]/span[1]"));
		return one;
	}

	public static WebElement two (WebDriver wd)
	{
		WebElement two=wd.findElement(By.xpath("//span[contains(text(),'2')]"));
		return two;
	}

	public static WebElement three (WebDriver wd)
	{
		WebElement three=wd.findElement(By.xpath("//span[contains(text(),'3')]"));
		return three;
	}

	public static WebElement four (WebDriver wd)
	{
		WebElement four=wd.findElement(By.xpath("//span[contains(text(),'4')]"));
		return four;
	}

	public static WebElement five (WebDriver wd)
	{
		WebElement five=wd.findElement(By.xpath("//span[contains(text(),'5')]"));
		return five;
	}

	public static WebElement six (WebDriver wd)
	{
		WebElement six=wd.findElement(By.xpath("//span[contains(text(),'6')]"));
		return six;

	}

	public static WebElement seven (WebDriver wd)
	{
		WebElement seven=wd.findElement(By.xpath("//span[contains(text(),'7')]"));
		return seven;
	}

	public static WebElement eight (WebDriver wd)
	{
		WebElement eight=wd.findElement(By.xpath("//span[contains(text(),'8')]"));
		return eight;
	}
	public static WebElement nine (WebDriver wd)
	{
		WebElement nine=wd.findElement(By.xpath("//span[contains(text(),'9')]"));
		return nine;

	}

}
